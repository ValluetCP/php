<?php
require_once "../inc/database.php";
// Interaction avec la base de donnée

class AnimalRepository{
    private $id_animal;
    private $name;
    private $type;
    private $breed;

    public function __construct($name,$type,$breed){
        $this->name = $name;
        $this->type = $type;
        $this->breed = $breed;
    }

    public function insert(){
        
    }
}