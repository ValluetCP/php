<?php
include_once "./form_actor.php"
?>
<button type="submit" id="bouton" class="btn btn-primary mt-5 mb-5" name="modif_actor" value="add_actor">Modifier un acteur</button>
</form>
</div>

<?php
include_once "./inc/footer.php";
?>