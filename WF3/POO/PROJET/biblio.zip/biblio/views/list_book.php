<?php
require_once "./inc/nav.php";

// version avec $_SESSION

// 1.Utiliser la session start
// session_start();

// 2.faire la condition
// if(isset($_SESSION['user_role'])){
//     echo "Bienvenue".$_SESSION['user_role'];
// }

// version avec $_COOKIE
if(isset($_COOKIE['user_role'])){ 
    echo "Bienvenue ".$_COOKIE['user_role'];?>
    <h1><?= "Bienvenue ".$_COOKIE['user_name']."!"; ?></h1>
<?php }

?>