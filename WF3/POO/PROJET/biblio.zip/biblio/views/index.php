<?php
// phpinfo();
echo "index";
?>
