<nav>
    <a href="http://localhost/php/WF3/POO/PROJET/biblio/home">Home</a>

    <?php if(isset($_COOKIE['user_role']) && $_COOKIE['user_role'] == "admin"){ ?>

        <a href="http://localhost/php/WF3/POO/PROJET/biblio/add_book">Add Book</a>

    <?php }else { ?>

        <a href="http://localhost/php/WF3/POO/PROJET/biblio/logs">Log</a>
        
    <?php } ?>
</nav>